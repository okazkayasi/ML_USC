clear all;
format short g;
q5();
q6();