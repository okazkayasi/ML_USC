lrTemplate()
knn_classify()
DecisionTree()
kNN()