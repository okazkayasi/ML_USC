function trainEvalModels()
    load toyGMM.mat
    
    %% MLE learning of model1, Gaussian Discriminative Analysis I
    % your code here
    % e.g. 
    % model1 = ...;
    % acc1 = ...;
    
    %% MLE learning of model2, Gaussian Discriminative Analysis II
    % your code here
    
    %% learning of model3, the MLR classifeir
    % your code here
    
    %% visualize and compare learned models
    % plotBoarder(model1, model2, model3, dataTe)
