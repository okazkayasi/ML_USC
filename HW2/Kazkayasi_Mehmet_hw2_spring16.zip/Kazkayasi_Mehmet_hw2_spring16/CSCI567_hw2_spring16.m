%% Once a while I get an ill-conditioned matrix error during stratified downsizing. Please
%% run it again in case.
question1();
trainEvalModels();
question3();