question1();
trainEvalModels();
question3();